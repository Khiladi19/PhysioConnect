export const SPECIALIZATIONS = [
  "All",
  "Ortho",
  "Neuro",
  "Post-Operative",
  "Sports Injury",
  "Geriatric",
];
