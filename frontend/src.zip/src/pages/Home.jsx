import { useState } from "react";
import Header from "../components/Header";
import Hero from "../components/Hero";
import SpecializationTabs from "../components/SpecializationTabs";
import DoctorCard from "../components/DoctorCard";
import RecommendedSection from "../components/RecommendedSection";
import BookingModal from "../components/BookingModal";
import WhatsappButton from "../components/WhatsAppFab";

export default function Home() {
  const [selectedTab, setSelectedTab] = useState("Ortho");
  const [openModal, setOpenModal] = useState(false);

  const doctors = [
    {
      id: 1,
      name: "Dr. Anjali Verma",
      specialization: "Orthopedic Physiotherapist",
      experience: 7,
      photo: "/doc1.jpg",
    },
    {
      id: 2,
      name: "Dr. Karan Patel",
      specialization: "Neurological Physiotherapist",
      experience: 5,
      photo: "/doc2.jpg",
    },
  ];

  return (
    <>
      <Header />
      <Hero />

      <SpecializationTabs selected={selectedTab} onChange={setSelectedTab} />

      <section className="px-4 py-6 max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {doctors.map((doc) => (
          <DoctorCard key={doc.id} doc={doc} />
        ))}
      </section>

      <RecommendedSection doctors={doctors} />

      <WhatsappButton />

      <BookingModal isOpen={openModal} onClose={() => setOpenModal(false)} />
    </>
  );
}
