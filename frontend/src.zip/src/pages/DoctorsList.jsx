import React from "react";
import { useSearchParams } from "react-router-dom";
import Grid from "../components/Grid";
import { DOCTORS } from "../data/doctors";

export default function DoctorsList() {
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get("q") || "";
  const spec = searchParams.get("spec") || "All";

  let list = DOCTORS;
  if (spec !== "All") list = list.filter((d) => d.spec === spec);
  if (q)
    list = list.filter((d) => d.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h2 className="text-xl font-semibold">Search Results</h2>
      <Grid doctors={list} onBook={() => {}} />
    </div>
  );
}
