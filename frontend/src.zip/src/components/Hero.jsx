import { motion } from "framer-motion";
// import heroImg from "../assets/doctor-hero.png"; 
import heroImg from "../assets/react.svg"; 

export default function Hero() {
  return (
    <section className="pt-28 pb-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight">
            Book{" "}
            <span className="text-indigo-600">Trusted Physiotherapists</span>
            <br />
            for Home Visit
          </h2>
          <p className="mt-3 text-gray-600 text-lg">
            Quick, expert-backed physiotherapy sessions at your home.
          </p>
          <button className="mt-6 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-medium shadow-md">
            Book a Home Session
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <img src={heroImg} className="w-full" alt="Physio Doctor" />
        </motion.div>
      </div>
    </section>
  );
}
