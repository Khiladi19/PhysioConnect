// export default function DoctorCard({ doc, onBook }) {
//   return (
//     <div className="bg-white rounded-xl p-4 shadow-sm flex gap-4 items-center">
//       <img
//         src={doc.photo}
//         alt={doc.name}
//         className="w-16 h-16 rounded-md object-cover"
//       />
//       <div className="flex-1">
//         <div className="flex items-start justify-between">
//           <div>
//             <div className="font-semibold">{doc.name}</div>
//             <div className="text-sm text-gray-500">
//               {doc.qual} • {doc.spec}
//             </div>
//             <div className="text-xs text-gray-400 mt-1">
//               {doc.exp} years experience
//             </div>
//           </div>

//           {doc.recommended && (
//             <div className="text-xs bg-yellow-100 text-yellow-900 px-2 py-1 rounded">
//               Trusted
//             </div>
//           )}
//         </div>

//         <div className="mt-3 flex gap-2">
//           <button
//             onClick={() => onBook(doc)}
//             className="text-sm px-3 py-2 rounded-md border hover:bg-indigo-50"
//           >
//             Book
//           </button>
//           <button className="text-sm px-3 py-2 rounded-md border text-gray-600">
//             View Profile
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }

export default function DoctorCard({ doc }) {
  return (
    <div className="p-5 bg-white rounded-2xl shadow hover:shadow-lg transition-all duration-200">
      <img
        src={doc.photo}
        alt={doc.name}
        className="h-40 w-full object-cover rounded-xl"
      />

      <h3 className="mt-4 font-semibold text-gray-900 text-lg">{doc.name}</h3>
      <p className="text-gray-600 text-sm">{doc.specialization}</p>
      <p className="text-gray-500 text-sm mt-1">
        Experience: {doc.experience} yrs
      </p>
    </div>
  );
}
