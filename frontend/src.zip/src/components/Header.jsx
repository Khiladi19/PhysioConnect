export default function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-30">
      <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-300 rounded-lg flex items-center justify-center text-white font-bold">
            PC
          </div>
          <h1 className="text-lg font-semibold">PhysioConnect</h1>
        </div>
        <nav className="hidden md:flex gap-6 text-sm text-gray-600">
          <a className="hover:underline" href="#about">
            About
          </a>
          <a className="hover:underline" href="#services">
            Services
          </a>
          <a className="hover:underline" href="#contact">
            Contact
          </a>
        </nav>
      </div>
    </header>
  );
}
